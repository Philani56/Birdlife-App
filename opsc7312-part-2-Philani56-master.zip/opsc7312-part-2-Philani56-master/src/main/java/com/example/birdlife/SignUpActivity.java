package com.example.birdlife;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUpActivity extends AppCompatActivity {

    // ------------------- Code Attribution -------------------
    // This code was contributed in:
    // Author: Codes Easy
    // Year: 2023
    // Title: Login and Registration using Firebase in Android
    // Url: https://www.youtube.com/watch?v=QAKq8UBv4GI

    private FirebaseAuth auth; // Firebase Authentication instance
    private EditText signupEmail, signupPassword; // EditText for user's email input & password input
    private Button signupButton;  // Button for signing up
    private TextView loginRedirectText; // TextView for redirecting to login

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Initialize Firebase Authentication instance
        auth = FirebaseAuth.getInstance();
        // Reference to UI elements
        signupEmail = findViewById(R.id.signup_email);
        signupPassword = findViewById(R.id.signup_password);
        signupButton = findViewById(R.id.signup_button);
        loginRedirectText = findViewById(R.id.loginRedirectText);

        // SignUp Button
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user input for email and password
                String user = signupEmail.getText().toString().trim();
                String pass = signupPassword.getText().toString().trim();

                // Validate email input
                if (user.isEmpty()) {
                    signupEmail.setError("Email cannot be empty");
                }
                // Validate password input
                if (user.isEmpty()) {
                    signupPassword.setError("Password cannot be empty");
                } else {
                    // Attempt to create a new user account using Firebase Authentication
                    auth.createUserWithEmailAndPassword(user, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Registration successful
                                Toast.makeText(SignUpActivity.this, "SignUp Successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(SignUpActivity.this, LoginActivity.class)); // Redirect to the login screen
                            } else {
                                // Registration failed, display error message
                                Toast.makeText(SignUpActivity.this, "Signup Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

            }
        });

        loginRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to the login screen
                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
            }
        });
    }
}