package com.example.birdlife

import retrofit2.http.GET

interface RequestManager {
    @GET("https://api.ebird.org/v2/data/obs/geo/recent?lat= -29.883333&lng=31.049999&sort=species")
    fun getObservation(): retrofit2.Call<List<ModelData>>
}