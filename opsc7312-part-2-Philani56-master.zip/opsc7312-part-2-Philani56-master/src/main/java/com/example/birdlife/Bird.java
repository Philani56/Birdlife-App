package com.example.birdlife;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Bird {
    private String name;
    private String location;
    private String Category;
    private String Notes;

    public Bird(String bird_name, String place, String tags) {
    }

    public Bird(String name, String location, String category, String notes) {
        this.name = name;
        this.location = location;
        Category = category;
        Notes = notes;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getCategory() {
        return Category;
    }

    public String getNotes() {
        return Notes;
    }
}
