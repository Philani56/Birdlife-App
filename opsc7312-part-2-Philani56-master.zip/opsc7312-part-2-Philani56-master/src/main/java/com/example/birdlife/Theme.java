package com.example.birdlife;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class Theme extends AppCompatActivity {

    boolean isNightModeOn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);

        // Get reference to the home button and switch button in the layout
        Button homeBtn = (Button) findViewById(R.id.logoutBtn); // Home button
        SwitchMaterial switchBtn = findViewById(R.id.switchBtn); // Switch button for toggling dark mode

// Check the default night mode and set initial state and text accordingly
        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_NO) {
            // Night mode is currently off
            isNightModeOn = false;
            switchBtn.setText("Enable Dark Mode");
        } else if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            // Night mode is currently on
            isNightModeOn = true;
            switchBtn.setText("Disable Dark Mode");
        } else {
            // Set default night mode to MODE_NIGHT_YES if not explicitly set
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }

// Set a click listener for the switch button to toggle between dark and light modes
        switchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isNightModeOn) {
                    // Switching to light mode
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    switchBtn.setText("Enable Dark Mode");
                    isNightModeOn = false;
                } else {
                    // Switching to dark mode
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    isNightModeOn = true;
                    switchBtn.setText("Disable Dark Mode");
                }
            }
        });

// Set a click listener for the home button to navigate back to the main activity
        homeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to navigate to the main activity
                Intent intent = new Intent(Theme.this, activity_menu.class);
                // Start the main activity
                startActivity(intent);
                // Finish the current activity (Theme activity)
                finish();
            }
        });
    }
}