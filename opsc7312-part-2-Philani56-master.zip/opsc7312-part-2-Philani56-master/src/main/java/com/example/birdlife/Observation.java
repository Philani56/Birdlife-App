package com.example.birdlife;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Observation extends AppCompatActivity {

    // ------------------- Code Attribution -------------------
    // This code was contributed in:
    // Author: All Coding tutorials
    // Year: Mar 1, 2022
    // Title: RecyclerView with SQLite Database | Populate RecyclerView with SQLite Database | Source Code
    // Url: https://www.youtube.com/watch?v=6enCz2cY18c



    Button btnInsert, btnView;
    EditText name, location, Category, Notes;
    DatabaseReference databaseBirds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_observation);

        btnInsert = findViewById((R.id.btnInsert));
        btnView = findViewById(R.id.btnView);

        name = findViewById(R.id.name);
        location = findViewById(R.id.location);
        Category = findViewById(R.id.tags);
        Notes = findViewById(R.id.editTextNotes);
        databaseBirds = FirebaseDatabase.getInstance().getReference();

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InsertData();
            }
        });


        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Observation.this, BirdList.class));
                finish();
            }
        });


    }

    private void InsertData() {

        String bird_name = name.getText().toString();
        String place = location.getText().toString();
        String tags = Category.getText().toString();
        String notes = Category.getText().toString();
        String id = databaseBirds.push().getKey();

        Bird bird = new Bird(bird_name, place, tags, notes);
        databaseBirds.child("birds").child(id).setValue(bird)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(Observation.this, "Bird Details Inserted", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }
}