package com.example.birdlife;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    private Context context;
    private ArrayList name_id, location_id, tags_id, notes_id;


    public CustomAdapter(Context context, ArrayList name_id, ArrayList location_id, ArrayList tags_id, ArrayList notes_id) {
        this.context = context;
        this.name_id = name_id;
        this.location_id = location_id;
        this.tags_id = tags_id;
        this.notes_id = notes_id;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.entry,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name_id.setText(String.valueOf(name_id.get(position)));
        holder.location_id.setText(String.valueOf(location_id.get(position)));
        holder.tags_id.setText(String.valueOf(tags_id.get(position)));
        holder.notes_id.setText(String.valueOf(notes_id.get(position)));
    }

    @Override
    public int getItemCount() {
        return name_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name_id, location_id, tags_id, notes_id;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name_id = itemView.findViewById(R.id.textname);
            location_id = itemView.findViewById(R.id.textlocation);
            tags_id = itemView.findViewById(R.id.textTags);
            notes_id = itemView.findViewById(R.id.textNotes);
        }
    }
}
