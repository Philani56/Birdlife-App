package com.example.birdlife;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.lang.reflect.Member;


// ------------------- Code Attribution -------------------
// This code was contributed in:
// Author: Indently
// Year: Apr 4, 2020
// Title: Saving data with Shared Preferences in Android Studio (Kotlin 2020)
// Url: https://www.youtube.com/watch?v=S5uLAGnBvUY


public class activity_settings extends AppCompatActivity {
    // Declare a private Switch variable for handling unit system switching.
    private Switch switchUnitSystem;
    // Declare a private EditText variable for inputting the maximum distance.
    private EditText editMaxDistance;
    // Declare Button variables for saving and going back.
    Button saveButton;
    Button backButton;

    Button gameButton;

    Button themeButton;

    DatabaseReference databaseSettings;
    private final String sharedPrefName = "BirdWatcherSettings"; // Define the name for the shared preferences file, which stores BirdWatcher settings.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize the 'switchUnitSystem' variable by finding the Switch element in the layout with the specified ID.
        switchUnitSystem = findViewById(R.id.switchUnitSystem);
        // Initialize the 'editMaxDistance' variable by finding the EditText element in the layout with the specified ID.
        editMaxDistance = findViewById(R.id.editMaxDistance);
        // Initialize the 'saveButton' variable by finding the Button element in the layout with the specified ID.
        saveButton = findViewById(R.id.save_button);
        // Initialize the 'backButton' variable by finding the Button element in the layout with the specified ID.
        backButton = findViewById(R.id.back_button);
        gameButton = findViewById(R.id.guess_button);
        themeButton = findViewById(R.id.theme_button);
        databaseSettings = FirebaseDatabase.getInstance().getReference();

        // Load the saved settings

        loadSettings();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save the settings when the Save button is clicked
                saveSettings();
                // Show a confirmation message to the user
                Toast.makeText(activity_settings.this, "Settings saved!", Toast.LENGTH_SHORT).show();
            }
        });

        // back to menu page
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity_settings.this, activity_menu.class));
                finish();
            }
        });

        // game word page
        gameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity_settings.this, FeatureOne.class));
                finish();
            }
        });
        // theme page
        themeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity_settings.this, Theme.class));
                finish();
            }
        });
    }

    // This method is used to save user settings in SharedPreferences.
    private void saveSettings() {
        // Get a reference to the SharedPreferences using the specified sharedPrefName and MODE_PRIVATE.
        SharedPreferences sharedPref = getSharedPreferences(sharedPrefName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit(); // Get an editor to make changes to the SharedPreferences.

        // Save the state of a switch (likely representing a unit system preference) as a boolean value.
        editor.putBoolean("isMetric", switchUnitSystem.isChecked());
        String maxDistanceString = editMaxDistance.getText().toString();

        // Convert the maxDistanceString to a floating-point number (float).
        // If the input is empty, set maxDistance to 0.0, otherwise parse the value
        float maxDistance = maxDistanceString.isEmpty() ? 0f : Float.parseFloat(maxDistanceString);
        editor.putFloat("maxDistance", maxDistance); // Save the maxDistance value in SharedPreferences.
        editor.apply(); // Apply the changes to the SharedPreferences editor.

        // Save to the database
        switchUnitSystem = findViewById(R.id.switchUnitSystem);
        editMaxDistance = findViewById(R.id.editMaxDistance);

    }

    private void loadSettings() {
        SharedPreferences sharedPref = getSharedPreferences(sharedPrefName, Context.MODE_PRIVATE);
        boolean isMetric = sharedPref.getBoolean("isMetric", true);
        float maxDistance = sharedPref.getFloat("maxDistance", 0f);

        switchUnitSystem.setChecked(isMetric);
        editMaxDistance.setText(String.valueOf(maxDistance));
    }
}
