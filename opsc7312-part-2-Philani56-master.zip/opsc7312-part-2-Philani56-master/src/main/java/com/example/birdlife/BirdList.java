package com.example.birdlife;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class BirdList extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Bird> List;
    DatabaseReference databaseReference;
    MyAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bird_list);

        // Initialize RecyclerView and related components
        recyclerView = findViewById(R.id.recyclerview);
        databaseReference = FirebaseDatabase.getInstance().getReference("birds");
        List = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyAdapter(this, List);
        recyclerView.setAdapter(adapter);

        // Retrieve data from Firebase and update the RecyclerView
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Clear the list to avoid duplicating data
                List.clear();

                // Loop through each snapshot in the data
                for(DataSnapshot dataSnapshot: snapshot.getChildren()) {
                    // Convert the snapshot data to a Bird object
                    Bird bird = dataSnapshot.getValue(Bird.class);

                    // Add the Bird object to the list
                    List.add(bird);
                }

                // Notify the adapter that the data has changed
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle any errors that occur during the data retrieval
            }
        });
    }
}