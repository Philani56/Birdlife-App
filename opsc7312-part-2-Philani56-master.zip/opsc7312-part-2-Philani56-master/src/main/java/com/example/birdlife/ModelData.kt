package com.example.birdlife

class ModelData (
    val speciesCode: String,
    val comName: String,
    val lat: Double,
    val lng: Double

    )
