package com.example.birdlife;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    // ------------------- Code Attribution -------------------
    // This code was contributed in:
    // Author: Codes Easy
    // Year: 2023
    // Title: Login and Registration using Firebase in Android
    // Url: https://www.youtube.com/watch?v=QAKq8UBv4GI

    // Create an instance of the FirebaseAuth class to manage user authentication.
    private FirebaseAuth auth;
    // References to the user interface elements in the layout.
    private EditText loginEmail, loginPassword;  // An EditText for entering the email & password.
    private Button loginButton; // A Button used to initiate the login process.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize the FirebaseAuth instance, which allows the app to interact with Firebase Authentication.
        auth = FirebaseAuth.getInstance();
        loginEmail = findViewById(R.id.login_email); // Find and initialize the 'loginEmail' EditText by its ID from the layout XML.
        loginPassword = findViewById(R.id.login_password); // Find and initialize the 'loginPassword' EditText by its ID from the layout XML.
        loginButton = findViewById(R.id.login_button); // Find and initialize the 'loginButton' Button by its ID from the layout XML.


        // Set an OnClickListener for the 'loginButton'
        // To access the Menu Activity
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = loginEmail.getText().toString();
                String pass = loginPassword.getText().toString();

                if(!email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches())
                {
                    if (!pass.isEmpty()) {
                        auth.signInWithEmailAndPassword(email, pass)
                                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        // Display a short-duration toast message to inform the user that login was successful.
                                        Toast.makeText(LoginActivity.this, "login Successful", Toast.LENGTH_SHORT).show();
                                        // Create an Intent to start the 'activity_menu' class.
                                        startActivity(new Intent(LoginActivity.this, activity_menu.class));
                                        finish(); // // Finish the current activity (LoginActivity) to prevent the user from returning to the login screen when they press the back button.
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // login failed
                                        Toast.makeText(LoginActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else{
                            loginPassword.setError(("Password cannot be empty")); // Check if the 'email' and 'password' fields are empty.
                    }
                } else if (email.isEmpty()) {
                    loginEmail.setError(("Email cannot be empty")); // If 'email' is empty, set an error message on the 'loginEmail' EditText to prompt the user to enter their email.
                } else{
                    // If both 'email' and 'password' are non-empty, it means 'email' is invalid.
                    // In this case, set an error message on the 'loginEmail' EditText to prompt the user to enter a valid email.
                    loginEmail.setError(("Please enter valid email"));
                }
            }
        });
    }
}


