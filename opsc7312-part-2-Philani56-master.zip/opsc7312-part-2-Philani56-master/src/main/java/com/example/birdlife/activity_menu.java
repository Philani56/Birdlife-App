package com.example.birdlife;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class activity_menu extends AppCompatActivity {

    // ------------------- Code Attribution -------------------
    // This code was contributed in:
    // Author: Technical Coding
    // Year: Jan 29, 2020
    // Title: How to Pass data from One to another Activity || Android studio tutorial
    // Url: https://www.youtube.com/watch?v=Yi8mxXsroJ4

    // Declare private member variables for buttons
    private Button mapButton; // Button for opening the map
    private Button settingsButton; // Button for opening the settings
    private Button logoutButton; // Button for logging out
    private Button observationButton; // Button for accessing observations
    private Button routeButton; //Button for calculating best route


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Initialize the buttons by finding them in the XML layout
        mapButton = findViewById(R.id.Map_button); // Map button initialization
        settingsButton = findViewById(R.id.Settings_button); // Settings button initialization
        observationButton = findViewById(R.id.observations_button); // Observations button initialization
        routeButton = findViewById(R.id.Route_button); // Calculating best route
        logoutButton = findViewById(R.id.logout_button); // Logout button initialization



        // Set a click listener for the mapButton
        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // When mapButton is clicked, start a new activity (MainActivity2) and finish the current activity.
                startActivity(new Intent(activity_menu.this, MapboxActivity.class));
                finish();
            }
        });

        // Set a click listener for the settingsButton
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // When settingsButton is clicked, start a new activity (activity_settings) and finish the current activity.
                startActivity(new Intent(activity_menu.this, activity_settings.class));
                finish();
            }
        });

        // Set a click listener for the observationButton
        observationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // When observationButton is clicked, start a new activity (ObservationActivity) and finish the current activity.
                startActivity(new Intent(activity_menu.this, Observation.class));
                finish();
            }
        });

        // Set a click listener for the routeButton
        routeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // When Route is clicked, start a new activity (RouteActivity) and finish the current activity.
                startActivity(new Intent(activity_menu.this, Route.class));
                finish();
            }
        });

        // Set a click listener for the logoutButton
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // When logoutButton is clicked, start a new activity (LoginActivity) and finish the current activity.
                startActivity(new Intent(activity_menu.this, LoginActivity.class));
                finish();
            }
        });
    }
}